import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:record/record.dart';
import 'package:path_provider/path_provider.dart';

void main() => runApp(const LamsaApp());

class LamsaApp extends StatefulWidget {
  const LamsaApp({super.key});
  @override
  State<LamsaApp> createState() => _LamsaAppState();
}

class _LamsaAppState extends State<LamsaApp> {
  Color seed = const Color(0xFFB83280);
  ThemeMode mode = ThemeMode.light;
  File? wallpaper;

  void updateSeed(Color color) => setState(() => seed = color);
  void updateMode(ThemeMode value) => setState(() => mode = value);
  void updateWallpaper(File? file) => setState(() => wallpaper = file);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'لمسة',
      debugShowCheckedModeBanner: false,
      themeMode: mode,
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      home: HomePage(
        seed: seed,
        mode: mode,
        wallpaper: wallpaper,
        onSeedChanged: updateSeed,
        onModeChanged: updateMode,
        onWallpaperChanged: updateWallpaper,
      ),
    );
  }

  ThemeData _theme(Brightness brightness) => ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: ColorScheme.fromSeed(seedColor: seed, brightness: brightness),
    scaffoldBackgroundColor: brightness == Brightness.light ? Colors.white : const Color(0xFF121212),
  );
}

class HomePage extends StatefulWidget {
  final Color seed;
  final ThemeMode mode;
  final File? wallpaper;
  final ValueChanged<Color> onSeedChanged;
  final ValueChanged<ThemeMode> onModeChanged;
  final ValueChanged<File?> onWallpaperChanged;

  const HomePage({
    super.key,
    required this.seed,
    required this.mode,
    required this.wallpaper,
    required this.onSeedChanged,
    required this.onModeChanged,
    required this.onWallpaperChanged,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;
  final picker = ImagePicker();

  Future<void> chooseWallpaper() async {
    final image = await picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (image != null) widget.onWallpaperChanged(File(image.path));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _feed(),
      const Center(child: Text('استكشاف')),
      const Center(child: Text('إضافة منشور')),
      const Center(child: Text('ريلز')),
      _profile(),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text('لمسة', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: widget.seed)),
          actions: [
            IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border)),
            IconButton(onPressed: () => Navigator.push(context, MaterialPageRoute(
              builder: (_) => ChatPage(wallpaper: widget.wallpaper),
            )), icon: const Icon(Icons.chat_bubble_outline)),
            IconButton(onPressed: _openSettings, icon: const Icon(Icons.palette_outlined)),
          ],
        ),
        body: IndexedStack(index: tab, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: tab,
          onDestinationSelected: (i) => setState(() => tab = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.search), label: 'استكشاف'),
            NavigationDestination(icon: Icon(Icons.add_box_outlined), label: 'إضافة'),
            NavigationDestination(icon: Icon(Icons.play_circle_outline), label: 'ريلز'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'حسابي'),
          ],
        ),
      ),
    );
  }

  Widget _feed() => ListView(
    children: [
      SizedBox(height: 105, child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.all(10),
        children: ['＋','🌸','🧑🏻','👩🏻','🌷','🧔🏻'].map((e) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 7),
          child: Column(children: [
            CircleAvatar(radius: 31, backgroundColor: widget.seed.withOpacity(.13),
              child: Text(e, style: const TextStyle(fontSize: 25))),
            const SizedBox(height: 4),
            const Text('حساب', style: TextStyle(fontSize: 11)),
          ]),
        )).toList(),
      )),
      const Divider(height: 1),
      _post('سارة', 'صباح مليء بالأمل والتفاؤل 💗', '🌷'),
      _post('محمد', 'أجمل الأوقات هي التي نقضيها مع من نحب ✨', '🌅'),
    ],
  );

  Widget _post(String name, String caption, String image) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      ListTile(
        leading: CircleAvatar(backgroundColor: widget.seed.withOpacity(.15), child: const Icon(Icons.person)),
        title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: const Text('العراق'),
        trailing: IconButton(onPressed: () {}, icon: const Icon(Icons.more_horiz)),
      ),
      Container(height: 260, width: double.infinity, color: widget.seed.withOpacity(.10),
        child: Center(child: Text(image, style: const TextStyle(fontSize: 80)))),
      Padding(padding: const EdgeInsets.all(12), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          IconButton(onPressed: () {}, icon: const Icon(Icons.favorite_border)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.mode_comment_outlined)),
          IconButton(onPressed: () {}, icon: const Icon(Icons.send_outlined)),
          const Spacer(),
          IconButton(onPressed: () {}, icon: const Icon(Icons.bookmark_border)),
        ]),
        Text('١٢٤ إعجاب', style: const TextStyle(fontWeight: FontWeight.bold)),
        Text('$name  $caption'),
      ])),
      const Divider(height: 1),
    ],
  );

  Widget _profile() => Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    CircleAvatar(radius: 42, backgroundColor: widget.seed.withOpacity(.15), child: const Icon(Icons.person, size: 45)),
    const SizedBox(height: 10),
    const Text('مستخدم لمسة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const Text('٠ منشورات     ٠ متابعون     ٠ أتابع'),
    const SizedBox(height: 14),
    OutlinedButton(onPressed: _openSettings, child: const Text('تخصيص المظهر')),
  ]));

  void _openSettings() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => AppearancePage(
      seed: widget.seed,
      mode: widget.mode,
      wallpaper: widget.wallpaper,
      onSeedChanged: widget.onSeedChanged,
      onModeChanged: widget.onModeChanged,
      onWallpaperChanged: widget.onWallpaperChanged,
    )));
  }
}

class AppearancePage extends StatelessWidget {
  final Color seed;
  final ThemeMode mode;
  final File? wallpaper;
  final ValueChanged<Color> onSeedChanged;
  final ValueChanged<ThemeMode> onModeChanged;
  final ValueChanged<File?> onWallpaperChanged;

  const AppearancePage({
    super.key, required this.seed, required this.mode, required this.wallpaper,
    required this.onSeedChanged, required this.onModeChanged, required this.onWallpaperChanged,
  });

  @override
  Widget build(BuildContext context) {
    final colors = [
      const Color(0xFFB83280), const Color(0xFF6750A4),
      const Color(0xFF16856B), const Color(0xFF1976D2),
      const Color(0xFFE66A24), const Color(0xFF444444),
      const Color(0xFFE84A5F), const Color(0xFF8A9A5B),
    ];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('تخصيص لمسة')),
        body: ListView(padding: const EdgeInsets.all(18), children: [
          const Text('لون التطبيق', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Wrap(spacing: 14, runSpacing: 14, children: colors.map((c) => InkWell(
            onTap: () => onSeedChanged(c),
            child: CircleAvatar(radius: 25, backgroundColor: c,
              child: seed.value == c.value ? const Icon(Icons.check, color: Colors.white) : null),
          )).toList()),
          const SizedBox(height: 28),
          const Text('المظهر', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          RadioListTile<ThemeMode>(value: ThemeMode.light, groupValue: mode,
            onChanged: (v) { if (v != null) onModeChanged(v); }, title: const Text('فاتح')),
          RadioListTile<ThemeMode>(value: ThemeMode.dark, groupValue: mode,
            onChanged: (v) { if (v != null) onModeChanged(v); }, title: const Text('داكن')),
          RadioListTile<ThemeMode>(value: ThemeMode.system, groupValue: mode,
            onChanged: (v) { if (v != null) onModeChanged(v); }, title: const Text('حسب إعدادات الهاتف')),
          const SizedBox(height: 18),
          const Text('خلفية المحادثات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          if (wallpaper != null) ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Image.file(wallpaper!, height: 150, fit: BoxFit.cover),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: () async {
              final image = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 85);
              if (image != null) onWallpaperChanged(File(image.path));
            },
            icon: const Icon(Icons.photo_library_outlined),
            label: const Text('اختيار صورة من المعرض'),
          ),
          TextButton(onPressed: () => onWallpaperChanged(null), child: const Text('إزالة الخلفية')),
          const SizedBox(height: 12),
          const Text('تغييرات الألوان والمظهر نموذج أولي محلي. حفظ التفضيلات بعد إغلاق التطبيق سيُضاف في مرحلة لاحقة.',
            style: TextStyle(color: Colors.grey)),
        ]),
      ),
    );
  }
}

class ChatPage extends StatefulWidget {
  final File? wallpaper;
  const ChatPage({super.key, this.wallpaper});
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final recorder = AudioRecorder();
  bool recording = false;
  String? lastRecording;
  String status = 'اضغطي مطولاً على زر المايك لبدء التسجيل';

  Future<void> startRecording() async {
    if (!await recorder.hasPermission()) {
      setState(() => status = 'يجب السماح باستخدام المايك من إعدادات الهاتف');
      return;
    }
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/lamsa_voice_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
    setState(() { recording = true; status = 'جارٍ تسجيل الصوت…'; });
  }

  Future<void> stopRecording() async {
    final path = await recorder.stop();
    setState(() {
      recording = false;
      lastRecording = path;
      status = path == null ? 'لم يتم حفظ التسجيل' : 'تم حفظ التسجيل على الجهاز';
    });
  }

  @override
  void dispose() {
    recorder.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Directionality(
    textDirection: TextDirection.rtl,
    child: Scaffold(
      appBar: AppBar(title: const Text('محادثة تجريبية')),
      body: Container(
        decoration: widget.wallpaper == null ? null : BoxDecoration(
          image: DecorationImage(image: FileImage(widget.wallpaper!), fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(Colors.white.withOpacity(.28), BlendMode.lighten)),
        ),
        child: Column(children: [
          const Expanded(child: Center(child: Text('هنا ستظهر الرسائل الصوتية والكتابية بعد ربط الحسابات والخادم.'))),
          Padding(padding: const EdgeInsets.all(18), child: Column(children: [
            Text(status),
            const SizedBox(height: 10),
            GestureDetector(
              onLongPressStart: (_) => startRecording(),
              onLongPressEnd: (_) { if (recording) stopRecording(); },
              child: CircleAvatar(radius: 34, backgroundColor: Theme.of(context).colorScheme.primary,
                child: Icon(recording ? Icons.stop : Icons.mic, color: Colors.white, size: 30)),
            ),
            const SizedBox(height: 8),
            const Text('اضغطي مطولاً للتسجيل'),
            if (lastRecording != null) const Text('التسجيل محفوظ محلياً — الإرسال للمستخدمين يحتاج ربط الخادم.',
              style: TextStyle(fontSize: 11, color: Colors.grey), textAlign: TextAlign.center),
          ])),
        ]),
      ),
    ),
  );
}
